package comMpas;
import java.util.*;

public class MapsImplementation {
    public static void main(String[] args) {
        // Create a HashMap
        Map<String, Integer> studentScores = new HashMap<>();

        // Add key-value pairs to the map
        studentScores.put("Alice", 90);
        studentScores.put("Bob", 85);
        studentScores.put("Charlie", 78);
        studentScores.put("David", 92);

        // Retrieve values by keys
        System.out.println("Alice's score: " + studentScores.get("Alice"));
        System.out.println("Charlie's score: " + studentScores.get("Charlie"));

        // Update a value
        studentScores.put("Bob", 88);
        System.out.println("Bob's updated score: " + studentScores.get("Bob"));

        // Check if a key exists in the map
        String studentName = "Eve";
        if (studentScores.containsKey(studentName)) {
            System.out.println(studentName + "'s score: " + studentScores.get(studentName));
        } else {
            System.out.println(studentName + " is not found in the map.");
        }

        // Remove a key-value pair
        studentScores.remove("David");
        System.out.println("David's score has been removed.");

        // Iterate through the map
        System.out.println("\nStudent scores:");
        for (Map.Entry<String, Integer> entry : studentScores.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        // Size of the map
        System.out.println("\nNumber of students in the map: " + studentScores.size());

        // Clear the map
        studentScores.clear();
        System.out.println("Map cleared. Number of students: " + studentScores.size());
    }
}

