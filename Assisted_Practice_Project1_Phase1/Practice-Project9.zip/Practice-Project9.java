package comArray;

public class ArrayEx1 {
	    public static void main(String[] args) {
	        // Declare an array of integers
	        int[] numbers;

	        // Initialize the array with 5 elements
	        numbers = new int[5];

	        // Assign values to the array elements
	        numbers[0] = 10;
	        numbers[1] = 20;
	        numbers[2] = 30;
	        numbers[3] = 40;
	        numbers[4] = 50;

	        // Access and display array elements
	        System.out.println("Array elements:");

	        for (int i = 0; i < numbers.length; i++) {
	            System.out.println("Element at index " + i + ": " + numbers[i]);
	        }

	        // Calculate the sum of array elements
	        int sum = 0;

	        for (int i = 0; i < numbers.length; i++) {
	            sum += numbers[i];
	        }

	        System.out.println("Sum of array elements: " + sum);

	        // Find the maximum element in the array
	        int max = numbers[0];

	        for (int i = 1; i < numbers.length; i++) {
	            if (numbers[i] > max) {
	                max = numbers[i];
	            }
	        }

	        System.out.println("Maximum element in the array: " + max);
	    }
	}


