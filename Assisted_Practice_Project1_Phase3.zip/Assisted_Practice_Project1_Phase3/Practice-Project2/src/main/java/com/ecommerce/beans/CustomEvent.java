package com.ecommerce.beans;

public class CustomEvent {

}
