package com.ecommerce.beans;

public class CustomEventPublisher {

}
