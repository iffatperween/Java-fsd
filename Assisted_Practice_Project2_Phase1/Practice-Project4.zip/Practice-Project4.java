package com.ThreadE;

public class TryCatch1 {
	public class ExceptionHandlingDemo {
	    public static void main(String[] args) {
	        try {
	            // Code that may throw an exception
	            int result = divide(10, 0); // Attempt to divide by zero
	            System.out.println("Result: " + result); // This line won't be executed
	        } catch (ArithmeticException e) {
	            // Catch the exception and handle it
	            System.out.println("An ArithmeticException occurred: " + e.getMessage());
	        }

	        System.out.println("Program continues after exception handling.");
	    }

	    // A method that can throw an exception
	    public static int divide(int numerator, int denominator) {
	        return numerator / denominator;
	    }
	}

}
