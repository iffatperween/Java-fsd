package com.ThreadE;

class CustomException1 extends Exception {
    public CustomException1(String message) {
        super(message);
    }
}

public class ThrowFinally1 {
    public static void main(String[] args) {
        try {
            int result = divide(10, 0);
            System.out.println("Result: " + result);
        } catch (CustomException1 e) {
            System.err.println("CustomException caught: " + e.getMessage());
        } catch (ArithmeticException e) {
            System.err.println("ArithmeticException caught: " + e.getMessage());
        } finally {
            System.out.println("Finally block executed.");
        }
    }

    public static int divide(int numerator, int denominator) throws CustomException1 {
        try {
            if (denominator == 0) {
                throw new CustomException1("Division by zero is not allowed.");
            }
            return numerator / denominator;
        } catch (ArithmeticException e) {
            // Re-throwing the exception with a custom message
            throw new CustomException1("An error occurred during division.");
        }
    }
}



