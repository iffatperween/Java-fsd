package com.ThreadE;

public class ExemptionHand {
	    public static void main(String[] args) {
	        try {
	            // Attempt to divide by zero
	            int numerator = 10;
	            int denominator = 0;
	            int result = numerator / denominator;
	            System.out.println("Result: " + result);
	        } catch (ArithmeticException e) {
	            // Catch and handle the ArithmeticException
	            System.err.println("An arithmetic exception occurred: " + e.getMessage());
	        } finally {
	            // The code in this block will always execute, regardless of whether an exception occurred or not
	            System.out.println("Finally block executed.");
	        }

	        System.out.println("Program continues after exception handling.");
	    }
	}


