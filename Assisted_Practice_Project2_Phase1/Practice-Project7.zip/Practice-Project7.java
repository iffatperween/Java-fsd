package com.ThreadE;
	import java.io.*;
	import java.util.Scanner;

	public class ReadCreate1 {

	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);

	        while (true) {
	            System.out.println("\nFile CRUD Menu:");
	            System.out.println("1. Create File");
	            System.out.println("2. Read File");
	            System.out.println("3. Update File");
	            System.out.println("4. Delete File");
	            System.out.println("5. Exit");
	            System.out.print("Enter your choice (1-5): ");

	            int choice = scanner.nextInt();
	            scanner.nextLine(); // Consume the newline character

	            switch (choice) {
	                case 1:
	                    createFile(scanner);
	                    break;
	                case 2:
	                    readFile(scanner);
	                    break;
	                case 3:
	                    updateFile(scanner);
	                    break;
	                case 4:
	                    deleteFile(scanner);
	                    break;
	                case 5:
	                    scanner.close();
	                    System.out.println("Exiting program.");
	                    System.exit(0);
	                default:
	                    System.out.println("Invalid choice. Please enter a valid option.");
	            }
	        }
	    }

	    private static void createFile(Scanner scanner) {
	        System.out.print("Enter the file name to create: ");
	        String fileName = scanner.nextLine();

	        try {
	            File file = new File(fileName);
	            if (file.createNewFile()) {
	                System.out.println("File created successfully: " + file.getAbsolutePath());
	            } else {
	                System.out.println("File already exists.");
	            }
	        } catch (IOException e) {
	            System.out.println("An error occurred while creating the file.");
	            e.printStackTrace();
	        }
	    }

	    private static void readFile(Scanner scanner) {
	        System.out.print("Enter the file name to read: ");
	        String fileName = scanner.nextLine();

	        try {
	            BufferedReader reader = new BufferedReader(new FileReader(fileName));
	            String line;
	            System.out.println("File contents:");
	            while ((line = reader.readLine()) != null) {
	                System.out.println(line);
	            }
	            reader.close();
	        } catch (IOException e) {
	            System.out.println("An error occurred while reading the file.");
	            e.printStackTrace();
	        }
	    }

	    private static void updateFile(Scanner scanner) {
	        System.out.print("Enter the file name to update: ");
	        String fileName = scanner.nextLine();

	        try {
	            FileWriter writer = new FileWriter(fileName, true);
	            System.out.println("Enter text to append to the file (Ctrl+D to stop):");
	            while (scanner.hasNextLine()) {
	                String line = scanner.nextLine();
	                writer.write(line + "\n");
	            }
	            writer.close();
	            System.out.println("File updated successfully.");
	        } catch (IOException e) {
	            System.out.println("An error occurred while updating the file.");
	            e.printStackTrace();
	        }
	    }

	    private static void deleteFile(Scanner scanner) {
	        System.out.print("Enter the file name to delete: ");
	        String fileName = scanner.nextLine();

	        File file = new File(fileName);
	        if (file.delete()) {
	            System.out.println("File deleted successfully.");
	        } else {
	            System.out.println("Failed to delete the file. It may not exist.");
	        }
	    }
	}


