package com.ThreadE;
//Define a class called "Person" to represent a person's attributes and behavior
class Person {
 // Attributes
 private String name;
 private int age;

 // Constructor
 public Person(String name, int age) {
     this.name = name;
     this.age = age;
 }

 // Encapsulation: Getter methods to access private attributes
 public String getName() {
     return name;
 }

 public int getAge() {
     return age;
 }

 // Abstraction: Method to display information about the person
 public void displayInfo() {
     System.out.println("Name: " + name);
     System.out.println("Age: " + age);
 }
}

//Define a subclass "Student" that inherits from the "Person" class
class Student extends Person {
 private String studentId;

 // Constructor
 public Student(String name, int age, String studentId) {
     super(name, age); // Call the superclass constructor
     this.studentId = studentId;
 }

 // Polymorphism: Override the displayInfo method to provide specific behavior
 @Override
 public void displayInfo() {
     super.displayInfo(); // Call the superclass method
     System.out.println("Student ID: " + studentId);
 }
}

public class Uses_of_clases1 {
 public static void main(String[] args) {
     // Create objects of the "Person" and "Student" classes
     Person person = new Person("Alice", 30);
     Student student = new Student("Bob", 20, "12345");

     // Call methods and demonstrate the OOP pillars
     System.out.println("Person Information:");
     person.displayInfo(); // Abstraction

     System.out.println("\nStudent Information:");
     student.displayInfo(); // Polymorphism

     // Inheritance
     System.out.println("\nInheritance Example:");
     System.out.println("Student Name: " + student.getName());
     System.out.println("Student Age: " + student.getAge());
 }
}

