package com.ThreadE;

	// Define an interface A with a default method
	interface A {
	    default void display() {
	        System.out.println("Inside Interface A");
	    }
	}

	// Define an interface B that extends A
	interface B extends A {
	    // No need to provide an implementation for display() here
	}

	// Define an interface C that extends A
	interface C extends A {
	    // No need to provide an implementation for display() here
	}

	// Define a class D that implements both B and C
	class D implements B, C {
	    // No need to provide an implementation for display() here
	}

	public class Diamond_prob1 {
	    public static void main(String[] args) {
	        D obj = new D();
	        obj.display(); // Calls the default method from Interface A
	    }
	}


