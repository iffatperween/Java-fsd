package com.Right;

public class RightRotateArr1 {
		    public static void main(String[] args) {
		        int[] originalArray = {1, 2, 3, 4, 5, 6, 7, 8, 9};
		        int steps = 5;

		        // Ensure steps is within the array length
		        steps %= originalArray.length;

		        int[] rotatedArray = rightRotate(originalArray, steps);

		        System.out.println("Original Array:");
		        printArray(originalArray);

		        System.out.println("\nRotated Array:");
		        printArray(rotatedArray);
		    }

		    // Function to right rotate an array by 'steps'
		    public static int[] rightRotate(int[] arr, int steps) {
		        int n = arr.length;
		        int[] rotatedArr = new int[n];

		        for (int i = 0; i < n; i++) {
		            // Calculate the new index after rotation
		            int newIndex = (i + steps) % n;
		            rotatedArr[newIndex] = arr[i];
		        }

		        return rotatedArr;
		    }

		    // Function to print an array
		    public static void printArray(int[] arr) {
		        for (int num : arr) {
		            System.out.print(num + " ");
		        }
		        System.out.println();
	


	}

}
