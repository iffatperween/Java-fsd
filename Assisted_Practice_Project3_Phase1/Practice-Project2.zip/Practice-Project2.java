package com.Right;
import java.util.PriorityQueue;
public class SmallestElement1 {
	
	
	    public static int findFourthSmallest(int[] arr) {
	        if (arr.length < 4) {
	            throw new IllegalArgumentException("Input list has less than four elements");
	        }

	        // Create a min-heap (priority queue)
	        PriorityQueue<Integer> minHeap = new PriorityQueue<>();

	        // Add the first four elements to the min-heap
	        for (int i = 0; i < 4; i++) {
	            minHeap.offer(arr[i]);
	        }

	        // Iterate through the remaining elements and keep track of the top 4 smallest
	        for (int i = 4; i < arr.length; i++) {
	            int current = arr[i];

	            // If the current element is smaller than the largest element in the min-heap
	            // (which is the root of the heap), replace it
	            if (current < minHeap.peek()) {
	                minHeap.poll(); // Remove the largest element
	                minHeap.offer(current); // Add the current element
	            }
	        }

	        // The fourth smallest element is the root of the min-heap
	        return minHeap.peek();
	    }

	    public static void main(String[] args) {
	        int[] arr = {12, 4, 7, 10, 8, 15, 2, 20};
	        int fourthSmallest = findFourthSmallest(arr);
	        System.out.println("The fourth smallest element is: " + fourthSmallest);
	    }
	}
