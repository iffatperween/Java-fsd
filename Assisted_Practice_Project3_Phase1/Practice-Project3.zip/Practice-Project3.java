package com.Right;
import java.util.Scanner;

public class SumOfNum1 {
	

	    @SuppressWarnings("resource")
		public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);
	        
	        // Input the number of elements in the array
	        System.out.print("Enter the number of elements (n): ");
	        int n = scanner.nextInt();
	        
	        if (n <= 0) {
	            System.out.println("Invalid input. The number of elements (n) must be greater than zero.");
	            return;
	        }
	        
	        // Create an array to store the elements
	        int[] arr = new int[n];
	        
	        // Input the elements
	        System.out.println("Enter the elements:");
	        for (int i = 0; i < n; i++) {
	            System.out.print("Element " + i + ": ");
	            arr[i] = scanner.nextInt();
	        }
	        
	        // Input the range [L, R]
	        System.out.print("Enter the left range index (L): ");
	        int L = scanner.nextInt();
	        System.out.print("Enter the right range index (R): ");
	        int R = scanner.nextInt();
	        
	        // Check if the range is valid
	        if (L < 0 || R >= n || L > R) {
	            System.out.println("Invalid range. Make sure 0 <= L <= R <= n-1.");
	        } else {
	            // Calculate the sum of elements in the specified range
	            int sum = 0;
	            for (int i = L; i <= R; i++) {
	                sum += arr[i];
	            }
	            System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);
	        }
	        
	        scanner.close();
	    }
	}



