package com.Circular1;

public class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    private Node head;

    public CircularLinkedList() {
        this.head = null;
    }

    // Method to insert a new element into the sorted circular linked list
    public void insertSorted(int newData) {
        Node newNode = new Node(newData);

        if (head == null) {
            head = newNode;
            head.next = head; // Circular reference
        } else if (newData <= head.data) {
            // Insert at the beginning
            newNode.next = head;
            Node last = getLastNode();
            last.next = newNode;
            head = newNode;
        } else {
            Node current = head;
            while (current.next != head && current.next.data < newData) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Helper method to get the last node in the circular linked list
    private Node getLastNode() {
        Node current = head;
        while (current.next != head) {
            current = current.next;
        }
        return current;
    }

    // Method to display the elements of the circular linked list
    public void display() {
        if (head == null) {
            System.out.println("List is empty.");
            return;
        }

        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }

    public static void main(String[] args) {
        CircularLinkedList cll = new CircularLinkedList();

        cll.insertSorted(5);
        cll.insertSorted(2);
        cll.insertSorted(8);
        cll.insertSorted(1);
        cll.insertSorted(7);

        System.out.println("Sorted Circular Linked List:");
        cll.display();
    }
}
