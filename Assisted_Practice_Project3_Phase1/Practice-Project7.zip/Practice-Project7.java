package com.dloblylinkEx;


	class Node {
	    int data;
	    Node next;
	    Node prev;

	    public Node(int data) {
	        this.data = data;
	        this.next = null;
	        this.prev = null;
	    }
	}

	class DoublyLinkedList {
	    Node head;
	    Node tail;

	    public void insert(int data) {
	        Node newNode = new Node(data);
	        if (head == null) {
	            head = newNode;
	            tail = newNode;
	        } else {
	            tail.next = newNode;
	            newNode.prev = tail;
	            tail = newNode;
	        }
	    }

	    public void traverseForward() {
	        Node current = head;
	        System.out.print("Forward traversal: ");
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.next;
	        }
	        System.out.println();
	    }

	    public void traverseBackward() {
	        Node current = tail;
	        System.out.print("Backward traversal: ");
	        while (current != null) {
	            System.out.print(current.data + " ");
	            current = current.prev;
	        }
	        System.out.println();
	    }
	}

	public class DoubleLinkedList1  {
	    public static void main(String[] args) {
	        DoublyLinkedList dll = new DoublyLinkedList();
	        
	        // Insert elements into the doubly linked list
	        dll.insert(1);
	        dll.insert(2);
	        dll.insert(3);
	        dll.insert(4);
	        dll.insert(5);

	        // Traverse in forward direction
	        dll.traverseForward();

	        // Traverse in backward direction
	        dll.traverseBackward();
	    }
	}


