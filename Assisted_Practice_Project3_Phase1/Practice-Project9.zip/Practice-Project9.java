package com.Right;
import java.util.LinkedList;
import java.util.Queue;

	public class RemoveFromQueue1 {
	    public static void main(String[] args) {
	        // Create a queue using LinkedList
	        Queue<Integer> queue = new LinkedList<>();

	        // Insert elements into the queue
	        queue.offer(18);
	        queue.offer(13);
	        queue.offer(25);

	        System.out.println("Queue after inserting elements: " + queue);

	        // Remove and print the front element of the queue
	        Integer removedElement = queue.poll();
	        System.out.println("Removed element: " + removedElement);

	        // Peek at the front element without removing it
	        Integer frontElement = queue.peek();
	        System.out.println("Front element (peeked): " + frontElement);

	        System.out.println("Queue after removing and peeking: " + queue);
	    }
	}


