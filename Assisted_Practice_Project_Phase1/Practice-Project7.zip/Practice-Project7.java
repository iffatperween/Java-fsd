package comInner;
//Outer class
class Outer {
 private int outerData = 10;

 // Inner class
 class Inner {
     void display() {
         System.out.println("Inner class method: " + outerData);
     }
 }

 // Method to create and use an instance of the inner class
 void useInner() {
     Inner innerObj = new Inner();
     innerObj.display();
 }
 public static void main(String[] args) {
     // Create an instance of the outer class
     Outer outerObj = new Outer();

     // Call the method to use the inner class
     outerObj.useInner();

     // You can also create an instance of the inner class directly
     Outer.Inner innerObj2 = outerObj.new Inner();
     innerObj2.display();
 }
}

public class InnerClass1 {

	public static void main(String[] args) {
	     // Create an instance of the outer class
	     Outer outerObj = new Outer();

	     // Call the method to use the inner class
	     outerObj.useInner();

	     // You can also create an instance of the inner class directly
	     Outer.Inner innerObj2 = outerObj.new Inner();
	     innerObj2.display();
	 }
	}
