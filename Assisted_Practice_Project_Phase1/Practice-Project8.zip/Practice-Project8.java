package comString;
    

public class StringBuffer1 {
	    public static void main(String[] args) {
	        // Create a String
	        String originalString = "Hello, World!";
	        
	        // Convert the String to StringBuffer
	        StringBuffer stringBuffer = new StringBuffer(originalString);
	        
	        // Convert the String to StringBuilder
	        StringBuilder stringBuilder = new StringBuilder(originalString);
	        
	        // Display the original String
	        System.out.println("Original String: " + originalString);
	        
	        // Display the StringBuffer
	        System.out.println("StringBuffer: " + stringBuffer.toString());
	        
	        // Display the StringBuilder
	        System.out.println("StringBuilder: " + stringBuilder.toString());
	    }
	}

