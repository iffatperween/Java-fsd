package coms.FileUploadAndDownloadServiceApp.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;
import coms.FileUploadAndDownloadServiceApp.model.FileInfo;
import coms.FileUploadAndDownloadServiceApp.model.ResponseUrl;
import coms.FileUploadAndDownloadServiceApp.service.FileInfoService;
import org.springframework.http.HttpHeaders;
@RestController
@RequestMapping("/api/v1")
public class FileInfoController {

	@Autowired
	FileInfoService fis;
	
	@PostMapping("/fupload")
	public ResponseEntity<Object> FileSaving(@RequestParam("file") MultipartFile file)
	{
		//System.out.println("Hello");
		if(fis.FileUpload(file).equals("Success"))
			return new ResponseEntity<Object>("File Uploaded Successfully", HttpStatus.CREATED);
		return new ResponseEntity<Object>("Error ! File Not Uploaded Successfully", HttpStatus.OK);
	}
	
	@GetMapping("/showall")
	public ResponseEntity<List<ResponseUrl>> GetAllInfo()
	{
		List<ResponseUrl>  responseAll = new ArrayList<ResponseUrl>();
		ResponseUrl rinfo = null;
		
		List<FileInfo>  fall = fis.ShowAll();
		
		// Generating URL for Download
		for(FileInfo f : fall)
		{
			String fileDownloadUrl = ServletUriComponentsBuilder
			          .fromCurrentContextPath()  // servername : http://localhost:9092
			          .path("api/v1/files/")		// getmapping text
			          .path(f.getFileid())  // id value from db
			          .toUriString();
			
			System.out.println(fileDownloadUrl);
			
			rinfo = new ResponseUrl();
			rinfo.setFilename(f.getFilename());
			rinfo.setFilesize(f.getFiledata().length);
			rinfo.setFileUrl(fileDownloadUrl);
			responseAll.add(rinfo);
		}	
		return new ResponseEntity<List<ResponseUrl>>(responseAll, HttpStatus.OK);
	}
	
	@GetMapping("/files/{id}")
	public ResponseEntity<byte[]>  GetFileDownload(@PathVariable("id") String id)	
	{
		FileInfo finfo = fis.GetAFile(id);
		if(finfo!=null)
		{
			//  download the file
			return ResponseEntity.ok()
			        .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + finfo.getFilename() + "\"")
			        .body(finfo.getFiledata());
		}

		return  new ResponseEntity("File Not Found", HttpStatus.NOT_FOUND); 
	}
}
