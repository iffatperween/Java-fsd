package coms.FileUploadAndDownloadServiceApp.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import coms.FileUploadAndDownloadServiceApp.model.FileInfo;

@Repository
public interface FileInfoRepository extends JpaRepository<FileInfo, String> {

}
