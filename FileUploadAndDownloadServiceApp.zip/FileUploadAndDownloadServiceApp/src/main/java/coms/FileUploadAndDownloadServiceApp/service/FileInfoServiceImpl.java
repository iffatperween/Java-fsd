package coms.FileUploadAndDownloadServiceApp.service;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import coms.FileUploadAndDownloadServiceApp.model.FileInfo;
import coms.FileUploadAndDownloadServiceApp.repo.FileInfoRepository;

@Service
public class FileInfoServiceImpl implements FileInfoService {

	@Autowired
	FileInfoRepository fir;
	
	@Override
	public String FileUpload(MultipartFile file) {
		String res = "err";
		try
		{
		FileInfo fileinfo = new FileInfo();
		
		fileinfo.setFilename(file.getOriginalFilename());
		fileinfo.setFiletype(file.getContentType());
		
		fileinfo.setFiledata(file.getBytes());

		FileInfo f = fir.save(fileinfo);
		if(f!=null)
			res ="Success";

		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
		
		
		return res;
	}

	@Override
	public List<FileInfo> ShowAll() {
		// TODO Auto-generated method stub
		return fir.findAll();
	}

	@Override
	public FileInfo GetAFile(String fileid) {
		
		Optional<FileInfo>  fs = fir.findById(fileid);
		
		if(fs.isPresent())
			return fs.get();
		
		return null;
	}
}
