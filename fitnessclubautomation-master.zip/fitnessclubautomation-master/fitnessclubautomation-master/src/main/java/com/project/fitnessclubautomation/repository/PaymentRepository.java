package com.project.fitnessclubautomation.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.project.fitnessclubautomation.model.Payment;

@Repository
public interface PaymentRepository extends CrudRepository<Payment, Long> {
}
